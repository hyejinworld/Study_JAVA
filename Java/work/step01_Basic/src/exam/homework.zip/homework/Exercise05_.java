package exam.homework;

public class Exercise05_ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 for(int x=0; x<=15; x++) {
	 for(int y=0; y <=12; y++) {
	 	if (4*x + 5*y == 60 ) {
		 System.out.println("("+ x + "," + y+ ")");
	 }
 }
	}

}
}
