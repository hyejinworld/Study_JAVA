package exam.homework;

public class Exercise04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 int pencils = 534;
 int students = 30;
 
 int penceilsPerStudent = pencils/students;
 System.out.println(penceilsPerStudent);
 
 int pencilsLeft = pencils%students;
 System.out.println(pencilsLeft);
	}

}
