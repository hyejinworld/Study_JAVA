package exam.homework;

public class Exercise05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int value = 356;
		 System.out.println(value / 100 * 100);
	}

}
