package exam.homework;

public class SungJuk {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		//double ns = (int)(Math.random()*12 + 1);
		//System.out.println("난수 = "+ns);
		
		String name = "혜진";
		int total = 0;
		char grade;
		

		
		
		int kor = (int)(Math.random() * 56) + 45; //100-45+1 최소값 45
		int eng = (int)(Math.random() * 56) + 45; //100-45+1 최소값 45
		int math = (int)(Math.random() * 56) + 45; //100-45+1 최소값 45
		
		total = kor + eng + math;
		int avg = total/3;
		
		
		//학점 if문, switch 문 
		
	
	/*	 if(avg >= 90 && avg < 100 )grade = 'A'; 
		 else if(avg >= 80 && avg < 90 )grade ='B'; 
		 else if(avg >= 70 && avg <80 )grade = 'C'; 
		 else if(avg >= 90 && avg <100)grade = 'D';
		 
		 default: grade ='F';*/
		
		
		switch((int)avg/10) {
		case 10 : grade ='A'; break;
		case  9 : grade ='B'; break;
		case  8 : grade ='C'; break;
		case  7 : grade ='D'; break;
	 
		default: grade ='F';
		
		}
		
		System.out.println(name+"님의 성적표");
		System.out.println("국어 :" + kor);
		System.out.println("영어 :" + eng);
		System.out.println("수학 :" + math);
		System.out.println("총점 :" + total);
		System.out.println("평균 :" + avg);
		System.out.println("등급 :" + grade);
	}

}
