package exam.homework;

public class Exercise04_ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Math.random();
		 
	}

}
